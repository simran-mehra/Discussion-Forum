import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  id = 'Accolite Id';
  name = 'Name';
  password = 'Password';
  confirm_password = 'Confirm Password'
  email = 'Email';
  location = 'Location';

  constructor(
    private http: HttpClient
  ) { }

  ngOnInit(): void {
  }

  register(): void{
    if(this.password!=this.confirm_password){
      console.log("Password not matched");
    }
    else{
    console.log(this.id,this.name,this.email,  this.password,this.location);
    this.http.post('http://localhost:8080/register', {id: this.id, name: this.name,
    email: this.email, password: this.password, location: this.location}, {responseType: 'text'})
    .subscribe(data  => {
      console.log(data);
    });
  }
  }



}
